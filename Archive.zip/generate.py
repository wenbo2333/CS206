import pyrosim.pyrosim as pyrosim
import pybullet_data

def Create_World():
    pyrosim.Start_SDF("box.sdf")
#    a = 1
#    b = 0
#   for i in range(10):
#        pyrosim.Send_Cube(name="Box1", pos=[0,0,b+0.5] , size=[a,a,a])
#        b += a
#        a = a*0.9
    pyrosim.Send_Cube(name="Box", pos=[-1,4,0.5] , size=[1,1,1])
    pyrosim.End()

def Create_Robot():
    pyrosim.Start_URDF("body.urdf")
    pyrosim.Send_Cube(name="Torso", pos=[0,0,1.5] , size=[1,1,1])
    pyrosim.Send_Joint( name = "Torso_Leg1" , parent= "Torso" , child = "BackLeg" , type = "revolute", position = "0 0 0")
    pyrosim.Send_Cube(name="BackLeg", pos=[1,0,0.5] , size=[1,1,1])
    pyrosim.Send_Joint( name = "Torso_Leg2" , parent= "Torso" , child = "FrontLeg" , type = "revolute", position = "0 0 0")
    pyrosim.Send_Cube(name="FrontLeg", pos=[-1,0,0.5] , size=[1,1,1])
    pyrosim.End()

def main():
    Create_World()
    Create_Robot()

if __name__ == "__main__":
    main()

def Save_Whitespace(depth,f):

    for d in range(0,depth):

        f.write('    ')
